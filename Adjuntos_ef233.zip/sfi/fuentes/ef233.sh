form4gl ef233a.per
fglpc ef233.4gl
fglpc gb000.4gl
fglpc gb001.4gl
cat ef233.4go gb000.4go gb001.4go >ef233.4gi
fglgo ef233.4gi EAY

